﻿namespace ByTheCakeApp.Data.Configuration
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server=.;Database=Cakes;Integrated Security=True;";
    }
}
