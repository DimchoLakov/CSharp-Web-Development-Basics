﻿using System.Linq;
using SIS.Framework.ActionResults.Interfaces;
using SIS.Framework.Attributes.Methods;

namespace IRunes.App.Controllers
{
    public class AlbumController : BaseController
    {
        [HttpGet("album/all")]
        public IActionResult All()
        {
            var albums = this.DbContext.Albums.ToList();

            if (albums.Any())
            {
                var listOfAlbums = string.Empty;
                foreach (var album in albums)
                {
                    var albumHtml = $@"<p><a href=""/albums/details/{album.Id}"">{album.Name}</a></p>";
                    listOfAlbums += albumHtml;
                }
                this.Model["Albums"] = listOfAlbums;
            }
            else
            {
                this.Model["Albums"] = "There are currently no albums.";
            }

            return this.View();
        }
    }
}
