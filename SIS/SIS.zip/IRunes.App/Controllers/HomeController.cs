﻿using SIS.Framework.ActionResults.Interfaces;

namespace IRunes.App.Controllers
{
    public class HomeController : BaseController
    {
        public IActionResult Index()
        {
            if (this.IsSignedIn())
            {
                return View("IndexLoggedIn");
            }
            return View();
        }
    }
}
