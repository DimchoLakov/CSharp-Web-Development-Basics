﻿namespace IRunes.Data.Configs
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-2G28R6E\SQLEXPRESS;Database=IRunes;Integrated Security=True";
    }
}
