﻿namespace IRunes.Data.Configs
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server=.;Database=IRunes;Integrated Security=True";
    }
}
