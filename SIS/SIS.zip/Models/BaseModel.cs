﻿namespace ByTheCakeApp.Models
{
    public abstract class BaseModel<T>
    {
        public T Id { get; set; }
    }
}
