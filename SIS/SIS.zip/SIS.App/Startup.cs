﻿using SIS.Framework.Api;
using SIS.Framework.Services;

namespace SIS.App
{
    public class Startup : MvcApplication
    {
        public override void ConfigureServices(IDependencyContainer dependencyContainer)
        {

        }
    }
}
