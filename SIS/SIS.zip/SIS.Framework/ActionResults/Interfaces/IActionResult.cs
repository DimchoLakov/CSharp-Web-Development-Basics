﻿namespace SIS.Framework.ActionResults.Interfaces
{
    public interface IActionResult
    {
        string Invoke();
    }
}
