﻿namespace SIS.Framework.ActionResults.Interfaces
{
    public interface IRenderable
    {
        string Render();
    }
}
